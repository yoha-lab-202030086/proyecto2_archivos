const mongoose = require('mongoose');
const Permiso = require('../models/Permiso');
const Usuario = require('../models/Usuario');
const Archivo = require('../models/Archivo');
const Carpeta = require('../models/Carpeta');
const { registrarActividad } = require('./actividad.service');

// Crear o actualizar los permisos de acceso para un recurso compartido
const compartirRecurso = async (recursoTipo, recursoId, usuarioDestinoId, nivel, propietarioId) => {
    if (!['ARCHIVO', 'CARPETA'].includes(recursoTipo)) {
        throw new Error('Tipo de recurso inválido');
    }

    if (!['LECTURA', 'EDICION'].includes(nivel)) {
        throw new Error('Nivel de permiso inválido');
    }

    const usuarioDestino = await Usuario.findById(usuarioDestinoId);
    if (!usuarioDestino) {
        throw new Error('El usuario destino no existe');
    }

    let recurso;
    if (recursoTipo === 'ARCHIVO') {
        recurso = await Archivo.findOne({ _id: recursoId, propietario: propietarioId, eliminado: false });
    } else {
        recurso = await Carpeta.findOne({ _id: recursoId, propietario: propietarioId, eliminada: false });
    }

    if (!recurso) {
        throw new Error('El recurso no existe o no pertenece al propietario');
    }

    if (propietarioId.toString() === usuarioDestinoId.toString()) {
        throw new Error('No es necesario compartir el recurso con el propietario');
    }

    const permisoExistente = await Permiso.findOne({ recursoTipo, recursoId, usuario: usuarioDestinoId });

    if (permisoExistente) {
        permisoExistente.nivel = nivel;
        permisoExistente.activo = true;
        await permisoExistente.save();
        
        await registrarActividad({
            usuario: propietarioId,
            accion: 'COMPARTIR_RECURSO',
            recursoTipo,
            recursoId,
            detalle: `Recurso compartido con el usuario ${usuarioDestinoId}`
        });

        return permisoExistente;
    }

    const permiso = new Permiso({ recursoTipo, recursoId, propietario: propietarioId, usuario: usuarioDestinoId, nivel });
    await permiso.save();

    await registrarActividad({
        usuario: propietarioId,
        accion: 'COMPARTIR_RECURSO',
        recursoTipo,
        recursoId,
        detalle: `Recurso compartido con el usuario ${usuarioDestinoId}`
    });

    return permiso;
};

// Comprobar los permisos de la cuenta considerando que la edicion otorga lectura automatica
const comprobarPermiso = async (usuarioId, recursoTipo, recursoId, nivelRequerido) => {
    const nivelesPermitidos = nivelRequerido === 'LECTURA'
        ? ['LECTURA', 'EDICION']
        : ['EDICION'];

    return await Permiso.findOne({
        usuario: usuarioId,
        recursoTipo,
        recursoId,
        nivel: { \$in: nivelesPermitidos },
        activo: true
    });
};

// Listar todos los permisos activos que tiene un recurso en específico
const listarPermisosRecurso = async (recursoTipo, recursoId, propietarioId) => {
    return await Permiso.find({ recursoTipo, recursoId, propietario: propietarioId, activo: true }).populate('usuario', 'nombre correo');
};

// Desactivar un permiso de acceso de forma lógica
const retirarPermiso = async (permisoId, propietarioId) => {
    const permiso = await Permiso.findOne({ _id: permisoId, propietario: propietarioId, activo: true });
    if (!permiso) {
        throw new Error('El permiso no existe');
    }
    permiso.activo = false;
    return await permiso.save();
};

// Cambiar el nivel de lectura a edición o viceversa
const modificarPermiso = async (permisoId, nuevoNivel, propietarioId) => {
    if (!['LECTURA', 'EDICION'].includes(nuevoNivel)) {
        throw new Error('Nivel de permiso inválido');
    }
    const permiso = await Permiso.findOne({ _id: permisoId, propietario: propietarioId, activo: true });
    if (!permiso) {
        throw new Error('El permiso no existe');
    }
    permiso.nivel = nuevoNivel;
    return await permiso.save();
};

module.exports = {
    compartirRecurso,
    comprobarPermiso,
    listarPermisosRecurso,
    retirarPermiso,
    modificarPermiso
};
